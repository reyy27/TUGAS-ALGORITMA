#include <iostream>
using namespace std;
int main()
{
  int a;
  cout <<" Program Perulangan Turun "<< endl;
  for (a = 10; a >= 1; --a)
    cout << a << " " << endl;
  
  cout <<" Program Perulangan Naik "<< endl;
  for(a=1; a<=10; a++)
    cout << a << " " << endl;
  getchar();
  }